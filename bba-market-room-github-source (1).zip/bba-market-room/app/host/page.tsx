import LegacySurface from '../../components/legacy-surface';
import {requireChatGPTUser} from '../chatgpt-auth';
export const dynamic='force-dynamic';
export default async function Host(){await requireChatGPTUser('/host');return <LegacySurface src="/host.mjs"><div id="app"><main className="join-shell"><h1>Opening your host room…</h1></main></div><dialog id="modal"/><div id="toast" role="status"/></LegacySurface>}
