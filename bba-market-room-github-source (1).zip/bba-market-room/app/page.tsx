import {redirect} from 'next/navigation';
import {getChatGPTUser} from './chatgpt-auth';
export const dynamic='force-dynamic';
export default async function Home(){const user=await getChatGPTUser();redirect(user?'/host':'/join')}
