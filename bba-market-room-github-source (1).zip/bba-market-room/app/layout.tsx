import type {Metadata} from 'next';
import './globals.css';
export const metadata:Metadata={title:'BBA Market Room',description:'Join a team investment game. Read the news, allocate your portfolio, and discover the historical year together.',icons:{icon:'/brand/bba-club-red.png'}};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><head><link rel="stylesheet" href="/style.css"/></head><body>{children}</body></html>}
