import {gameApi} from '../../../../lib/game-api';
export const dynamic='force-dynamic';
export const GET=gameApi;
export const POST=gameApi;
