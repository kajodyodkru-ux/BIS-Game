export const ASSETS=['Cash','Bitcoin','Gold','Gov. bonds','U.S. stocks','China stocks','Thai stocks'];
export function standings(teams){return [...teams].sort((a,b)=>b.value-a.value||a.id-b.id);}
export function riskEligible(teams){const sorted=standings(teams),cut=sorted[Math.ceil(sorted.length/2)-1].value;return sorted.filter(t=>t.value>=cut-1e-8).sort((a,b)=>a.drawdown-b.drawdown||b.value-a.value);}
export function awardWinners(teams){const sorted=standings(teams),risk=riskEligible(teams);return {returns:sorted.filter(t=>Math.abs(t.value-sorted[0].value)<1e-8),risk:risk.filter(t=>Math.abs(t.drawdown-risk[0].drawdown)<1e-8)};}

export const PRICE_SOURCES=[
 {name:'Bitcoin · BTC-USD',url:'https://finance.yahoo.com/quote/BTC-USD/history/',basis:'Daily USD close; calendar days, UTC.'},
 {name:'Gold · GLD',url:'https://finance.yahoo.com/quote/GLD/history/',basis:'SPDR Gold Shares ETF adjusted close; gold exposure after fund expenses.'},
 {name:'Government bonds · IEF',url:'https://finance.yahoo.com/quote/IEF/history/',basis:'iShares 7–10 Year Treasury Bond ETF adjusted close; distributions included.'},
 {name:'U.S. stocks · SPY',url:'https://finance.yahoo.com/quote/SPY/history/',basis:'SPDR S&P 500 ETF adjusted close; distributions included.'},
 {name:'China stocks · MCHI',url:'https://finance.yahoo.com/quote/MCHI/history/',basis:'iShares MSCI China ETF adjusted close in USD; distributions and currency effects included. Not a mainland-only index.'},
 {name:'Thai stocks · THD',url:'https://finance.yahoo.com/quote/THD/history/',basis:'iShares MSCI Thailand ETF adjusted close in USD; distributions and currency effects included. Not the THB SET Index.'}
];
