// Reveal historical observations in calendar order without altering the data or axis scale.
const playback=new Map();
let frame=0;
const duration=6000;
export function mountMarketReplay(root){
 if(typeof root.querySelectorAll!=='function')return;
 cancelAnimationFrame(frame);
 const panel=root.querySelector('[data-market-playback]');if(!panel)return;
 const key=panel.dataset.marketPlayback,reduced=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
 let state=playback.get(key);if(!state){state={progress:reduced?1:0,running:!reduced,resultsVisible:false};playback.set(key,state);}
 const clip=panel.querySelector('[data-playback-clip]'),cursor=panel.querySelector('[data-playback-cursor]'),label=panel.querySelector('[data-playback-date]'),toggle=panel.querySelector('[data-playback-toggle]');
 const days=Number(panel.dataset.days),year=Number(panel.dataset.year);
 const results=root.querySelector('[data-round-results]'),status=root.querySelector('[data-reveal-status]'),end=panel.querySelector('[data-playback-end]');
 let last=0;
 function paint(){
  const width=700*state.progress;clip.setAttribute('width',String(width+2));cursor.setAttribute('x1',String(60+width));cursor.setAttribute('x2',String(60+width));cursor.style.opacity=state.progress>=1?'0':'1';
  const day=Math.max(0,Math.ceil(days*state.progress)-1),date=new Date(Date.UTC(year,0,day+1));
  label.textContent=state.progress===0?'Start of year':state.progress>=1?'Year end · full history':date.toLocaleDateString('en-GB',{day:'numeric',month:'short',timeZone:'UTC'});
  toggle.textContent=state.running?'Pause':state.progress>=1?'Replay year':'Continue';toggle.setAttribute('aria-label',state.running?'Pause market replay':state.progress>=1?'Replay market year':'Continue market replay');
  if(reduced){toggle.textContent='Reduced motion';toggle.setAttribute('aria-label','Animation disabled by reduced motion preference');}
  if(results)results.hidden=!state.resultsVisible;
  if(status){status.hidden=state.resultsVisible;status.textContent=reduced?'The full market path is shown with motion reduced. Select Show results when you are ready.':'Watch the year unfold. Final returns and team totals appear after the replay.';}
  end.disabled=state.resultsVisible;end.textContent=state.resultsVisible?'Results shown':reduced?'Show results':'Skip to results';
 }
 function tick(now){
  if(!panel.isConnected)return;
  if(last&&state.running)state.progress=Math.min(1,state.progress+(now-last)/duration);
  last=now;if(state.progress>=1){state.running=false;state.resultsVisible=true;}paint();
  if(state.running)frame=requestAnimationFrame(tick);
 }
 toggle.addEventListener('click',()=>{
  cancelAnimationFrame(frame);last=0;
  if(reduced){state.progress=1;state.running=false;paint();return;}
  if(state.progress>=1){state.progress=0;state.running=true;state.resultsVisible=false}else state.running=!state.running;
  paint();if(state.running)frame=requestAnimationFrame(tick);
 });
 end.addEventListener('click',()=>{cancelAnimationFrame(frame);state.progress=1;state.running=false;state.resultsVisible=true;paint();});
 if(reduced){state.progress=1;state.running=false;toggle.disabled=true;toggle.textContent='Reduced motion';}
 paint();if(reduced){toggle.textContent='Reduced motion';toggle.setAttribute('aria-label','Animation disabled by reduced motion preference');}
 if(state.running)frame=requestAnimationFrame(tick);
}
