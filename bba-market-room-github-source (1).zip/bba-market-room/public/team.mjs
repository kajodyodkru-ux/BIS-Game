const root=document.querySelector('#team-app');
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const initial=new URLSearchParams(location.search).get('room')||'';
let busy=false,checkNumber=0;
root.innerHTML=`<main class="join-shell"><div class="brand"><img class="club-logo" src="/brand/bba-club-red.png" alt="BBA Investment Society logo" width="48" height="48"><div><strong>MARKET ROOM</strong><small>BBA INVESTMENT SOCIETY</small></div></div><div class="eyebrow">SCAN. JOIN. INVEST.</div><h1>Join the game.</h1><p>Enter the PIN shown by your host and choose a team name.</p><form id="join-form"><label for="room-code">Game PIN</label><input id="room-code" name="room" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" minlength="6" value="${esc(/^\d{6}$/.test(initial)?initial:'')}" placeholder="000000" required autocomplete="off" aria-describedby="lobby-status" aria-label="Six-digit game PIN"><div id="lobby-status" class="join-room-status" role="status">Enter the six-digit PIN on the host’s screen.</div><label for="team-name">Team name</label><input id="team-name" name="name" maxlength="30" placeholder="e.g. The Investors" required autocomplete="off" autocapitalize="words"><p id="team-message" role="alert"></p><button class="primary" type="submit">Join game →</button></form><div class="join-note"><strong>One device. One team portfolio.</strong><p>Keep this browser tab to reconnect. Your submitted investments are saved.</p></div><p class="join-private">Join with the host’s QR code or six-digit PIN. Players do not need an account.</p><div class="join-secondary"><a class="text-link" href="/play?preview=1">Try the player preview</a><a class="text-link" href="/host">Host a game →</a></div></main>`;
const pin=document.querySelector('#room-code'),name=document.querySelector('#team-name'),status=document.querySelector('#lobby-status'),message=document.querySelector('#team-message'),button=document.querySelector('button[type="submit"]');
async function api(path,body){
 const res=await fetch('/api/game/'+path,{method:body?'POST':'GET',credentials:'same-origin',cache:'no-store',headers:body?{'Content-Type':'application/json'}:{},body:body?JSON.stringify(body):undefined});
 if(!res.headers.get('content-type')?.includes('application/json'))throw Error('Could not connect to the game. Reload this page and try again.');
 const data=await res.json();if(!res.ok)throw Object.assign(Error(data.error||'Connection unavailable. Please try again.'),{status:res.status});return data;
}
async function inspectRoom(){
 const code=pin.value,seq=++checkNumber;button.disabled=busy;
 if(!/^\d{6}$/.test(code)){status.textContent='Enter the six-digit PIN on the host’s screen.';return;}
 status.textContent='Checking the room…';
 try{
  try{const current=await api(`room/${code}`);if(seq!==checkNumber||busy)return;location.replace(`/play?room=${current.code}`);return;}catch(e){if(e.status!==401)throw e;}
  const room=await api(`room/${code}/lobby`);if(seq!==checkNumber||busy)return;
  status.textContent=room.accepting?`Lobby open · ${room.teamCount} / ${room.capacity} teams joined`:room.message;
  button.disabled=!room.accepting;
 }catch(e){if(seq===checkNumber&&!busy){status.textContent=e.message;button.disabled=!!e.status&&e.status!==401;}}
}
pin.addEventListener('input',()=>{pin.value=pin.value.replace(/\D/g,'').slice(0,6);message.textContent='';inspectRoom();});
document.querySelector('#join-form').addEventListener('submit',async e=>{
 e.preventDefault();if(busy)return;const code=pin.value.trim(),teamName=name.value.trim();
 if(!/^\d{6}$/.test(code)||!teamName){message.textContent='Enter a six-digit PIN and your name.';return;}
 busy=true;++checkNumber;button.disabled=true;button.textContent='Joining the room…';pin.disabled=true;name.disabled=true;message.textContent='';
 try{await api(`room/${code}/join`,{name:teamName});location.replace(`/play?room=${code}`);}
 catch(e){message.textContent=e.message;message.setAttribute('tabindex','-1');message.focus();busy=false;button.disabled=false;button.textContent='Join game →';pin.disabled=false;name.disabled=false;}
});
if(/^\d{6}$/.test(pin.value)){name.focus();inspectRoom();}else pin.focus();
setInterval(()=>{if(!busy&&button.disabled)inspectRoom();},5000);
