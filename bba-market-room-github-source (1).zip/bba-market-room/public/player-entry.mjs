if(new URLSearchParams(location.search).get('preview')==='1')await import('./player-preview.mjs');else await import('./player.mjs');
