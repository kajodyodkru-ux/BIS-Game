// Shared by the live player and the clearly labelled preview.
export function editAllocation(weights,index,value){
 const next=[...weights],number=Number(value);
 if(index<1||index>=next.length)return next;
 next[index]=Number.isFinite(number)?Math.max(0,Math.min(100,Math.round(number*10)/10)):0;
 const invested=Math.round(next.slice(1).reduce((a,b)=>a+b,0)*10)/10;
 next[0]=Math.max(0,Math.round((100-invested)*10)/10);
 return next;
}
export function refreshAllocation(root,weights,value,{busy=false,offline=false,submitted=false,saved=[]}={}){
 const total=Math.round(weights.reduce((a,b)=>a+b,0)*10)/10,over=Math.max(0,Math.round((total-100)*10)/10),valid=total===100&&weights.every(v=>Number.isFinite(v)&&v>=0&&v<=100);
 const cash=root.querySelector('#cash-weight');if(!cash)return;
 cash.textContent=weights[0].toFixed(1).replace('.0','')+'%';
 root.querySelector('#cash-amount').textContent=Math.round(value*weights[0]/100).toLocaleString('en-US');
 root.querySelector('#budget-label').textContent=over?`Reduce investments by ${over}%`:`${weights[0]}% cash · ${Math.round((100-weights[0])*10)/10}% invested`;
 root.querySelector('#budget-total').textContent=over?`${total}% / 100%`:'100% allocated';
 root.querySelector('#budget-fill').style.width=Math.min(100,total)+'%';
 root.querySelector('.p-submit-box').classList.toggle('is-invalid',!valid);
 weights.forEach((w,i)=>{const amount=root.querySelector('#amount-'+i);if(amount)amount.textContent=Math.round(value*w/100).toLocaleString('en-US');const segment=root.querySelector(`[data-segment="${i}"]`);if(segment)segment.style.width=`${w/Math.max(100,total)*100}%`;});
 const changed=weights.some((w,i)=>Math.abs(w-(saved[i]??0))>.00001),status=root.querySelector('#draft-state');
 status.textContent=busy?'Saving…':submitted?(changed?'Unsaved changes':'Saved allocation'):'Not submitted';status.dataset.state=submitted&&!changed?'saved':'draft';
 root.querySelector('#submit-allocation').disabled=busy||offline||!valid;
 const restore=root.querySelector('[data-action="restore"]');if(restore)restore.disabled=busy||!changed;
 return valid;
}
